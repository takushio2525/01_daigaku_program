コンパイルの方法: 二分法の場合
gcc bisection_search.c -o bisection_search.out -lm

コンパイル法: ニュートン法の場合
gcc newtown_search.c -o newtown_search.out -lm

